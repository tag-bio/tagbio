## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----create_fc, echo=TRUE, message=F, warning=F-------------------------------

library(tagbio)
library(tidyverse)

# set up connection to the FC
fc_hnsc <- FC(name = "fc-hnsc", 
              url = "https://fc-genesig-gateway-azure.dev.tag.bio/fc-svc/fc-hnsc/")


## ----create_protocol, echo=TRUE, message=F, warning=F-------------------------

# leukocyte infiltration signature genes
leuk_genes <- c("CD19", "CD37", "CD3D", "CD3E", "CD3G", "CD247", "CD79A", 
    "CD79B", "CD8A",  "CD14", "LCK", "LTB", "MS4A1")

# define the protocol instance
prot_inst <- ProtocolInstance(name = "download", 
    arguments = list(expression = leuk_genes,
                     clinical_categorical_variables = c("clinical.SAMPLE_ID")))


## ----get_data, echo=TRUE, message=F, warning=F--------------------------------

# get data from tagbio
tag_data <- getTagData(fc_hnsc, prot_inst) 
tag_data@data.frame[c(1:5),c(1:4)]


## ----get_expr_array, echo=TRUE, message=F, warning=F--------------------------

# get a table of the gene expression results
exp_data <- getDataFrame(tag_data, data_type = "Expression", 
                         row_name ="clinical.SAMPLE_ID")
exp_data[c(1:5), c(1:5)]


## ----draw_heat_map, echo=TRUE, message=F, warning=F---------------------------

library(gplots)

# remove NA's from expression matrix
exp_data <- exp_data %>% replace(is.na(.), 0)

# convert tibble to a matrix for use in heatmap
exp_matrix <- as.matrix(exp_data)

# draw the heatmap
heatmap.2(exp_matrix, scale="column", trace="none", 
    key = FALSE, margin=c(6,8))


