## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----create_fc, echo=TRUE, message=F, warning=F-------------------------------

library(tagbio)

# set up connection to the FC
fc_hnsc <- FC(name = "fc-hnsc", url = "https://fc-genesig-gateway-azure.dev.tag.bio/fc-svc/fc-hnsc/")


## ----create_protocol, echo=TRUE, message=F, warning=F-------------------------

# leukocyte infiltration signature genes
leuk_genes <- c("CCL5", "CD19", "CD37", "CD3D", "CD3E", "CD3G", "CD3Z", "CD79A", "CD79B", "CD8A",
    "CD8B1", "IGHG3", "IGJ", "IGLC1", "CD14", "LCK", "LTB", "MS4A1")
leuk_genes <- c("A1CF","A2M")

# define protocol instance
prot_inst <- ProtocolInstance(name = "download", 
    arguments = list(expression = leuk_genes,
                     clinical_categorical_variables = c("clinical.SAMPLE_ID")))


## ----get_data, echo=TRUE, message=F, warning=F--------------------------------

# get

exp_data <- getTagData(fc_hnsc, prot_inst) 
exp_data


