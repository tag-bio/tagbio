## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- eval=F------------------------------------------------------------------
#  # install tidyverse and tagbio's SDK
#  library(tidyverse)
#  library(tagbio)
#  
#  # paste in your API key here
#  tag_con <- tagConnect(host_url = "https://aws-demo-cluster.dev.tag.bio",
#                        api_key = "<API_KEY>")

## ---- echo=F,warning=F,message=F----------------------------------------------

# do it for real using local API KEY
# install tidyverse and tagbio's SDK
library(tidyverse)
library(tagbio)

# paste in your API key here
tag_con <- tagConnect(host_url = "https://aws-demo-cluster.dev.tag.bio")


## -----------------------------------------------------------------------------
# view data products
summary(tag_con)

## -----------------------------------------------------------------------------
# connect to the data product
fc <- tagFC(tag_con, "fc-catalyze")

# view the data collections
summary(fc)

## ---- fig.height=8, fig.width=8-----------------------------------------------

# pull unique patient-cancer list from data product
patients_per_cancer <- fc %>% 
  select(`Patient ID`, `Cancer Subtype`) %>%
  collect() %>%
  filter(!is.na(`Cancer Subtype` != "NA")) %>%
  distinct()

# make a graph
ggplot(patients_per_cancer, aes(x = `Cancer Subtype`, fill = `Cancer Subtype`)) +
  geom_bar(stat = "count") +
  coord_flip() +
  theme_bw() +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1),
                                   legend.position = "none") +
  ggtitle("Number Patients per Cancer Subtype")


