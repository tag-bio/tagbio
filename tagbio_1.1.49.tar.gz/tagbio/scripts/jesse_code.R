function(tag_data, tag_result) {

    data <- tagbio::get_results(tag_data)
    no_genotypes <- data %>%
    filter(is.na(`Patient genotype - heterozygous reference/alternate`),
            is.na(`Patient genotype - homozygous alternate`))

    het_genotypes <- data %>%
        filter(!is.na(`Patient genotype - heterozygous reference/alternate`)) %>%
        separate_rows(`Patient genotype - heterozygous reference/alternate`, sep = "; ?") %>%
        mutate(`Patient genotype - homozygous alternate` = NA)

    hom_genotypes <- data %>%
        filter(!is.na(`Patient genotype - homozygous alternate`)) %>%
        separate_rows(`Patient genotype - homozygous alternate`, sep = "; ?") %>%
        mutate(`Patient genotype - heterozygous reference/alternate` = NA)

    new_data <- no_genotypes %>%
        rbind(het_genotypes) %>%
        rbind(hom_genotypes)

    write.csv(new_data, tag_result$output_path, row.names = FALSE)

    return(tag_result)
}