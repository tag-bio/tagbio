#library(tagbio)

tag_con <- tagConnect(host_url = "https://aws-demo-cluster.dev.tag.bio")
fc <- tagFC(tag_con, "fc-catalyze")

# view the data collections
summary(fc)

